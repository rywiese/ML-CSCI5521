% 2a/2b (2b was done with line 114-115 in EMG.m uncommented)
for k = [4, 8, 12]
    [h, m, Q] = EMG(0, 'stadium.bmp', k);
end

% 2c-e
hw3_Q2_ce;
